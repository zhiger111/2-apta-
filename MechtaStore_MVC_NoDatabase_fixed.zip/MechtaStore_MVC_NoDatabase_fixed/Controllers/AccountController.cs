using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Authentication;using System.Security.Claims;using MechtaStore.Services;using MechtaStore.Models;
namespace MechtaStore.Controllers;
public class AccountController:Controller {readonly StoreService s;public AccountController(StoreService x)=>s=x;
[HttpGet]public IActionResult Login()=>View(new LoginVm());
[HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Login(LoginVm m){if(!ModelState.IsValid)return View(m);var u=s.FindUser(m.Email.Trim().ToLower());if(u==null||!BCrypt.Net.BCrypt.Verify(m.Password,u.PasswordHash)){ModelState.AddModelError("","Неверный email или пароль");return View(m);}await SignIn(u);return RedirectToAction("Index","Home");}
[HttpGet]public IActionResult Register()=>View(new RegisterVm());
[HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Register(RegisterVm m){if(!ModelState.IsValid)return View(m);var email=m.Email.Trim().ToLower();if(s.FindUser(email)!=null){ModelState.AddModelError("Email","Этот email уже зарегистрирован");return View(m);}var u=s.AddUser(new User{FullName=m.FullName.Trim(),Email=email,PasswordHash=BCrypt.Net.BCrypt.HashPassword(m.Password)});await SignIn(u);return RedirectToAction("Index","Home");}
async Task SignIn(User u){var c=new[]{new Claim(ClaimTypes.NameIdentifier,u.Id.ToString()),new Claim(ClaimTypes.Name,u.FullName),new Claim(ClaimTypes.Email,u.Email),new Claim(ClaimTypes.Role,u.Role.ToString())};await HttpContext.SignInAsync("MechtaCookie",new ClaimsPrincipal(new ClaimsIdentity(c,"MechtaCookie")));}
[HttpPost,Microsoft.AspNetCore.Authorization.Authorize]public async Task<IActionResult> Logout(){await HttpContext.SignOutAsync("MechtaCookie");return RedirectToAction("Index","Home");}
}