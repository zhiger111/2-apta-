using Microsoft.AspNetCore.Mvc;using MechtaStore.Services;
namespace MechtaStore.Controllers;
public class ProductsController:Controller {readonly StoreService s;public ProductsController(StoreService x)=>s=x;
public IActionResult Index(int? categoryId,string? search){var q=s.Products.AsEnumerable();if(categoryId.HasValue)q=q.Where(p=>p.CategoryId==categoryId);if(!string.IsNullOrWhiteSpace(search))q=q.Where(p=>p.Name.Contains(search.Trim(),StringComparison.OrdinalIgnoreCase));ViewBag.Categories=s.Categories;ViewBag.CategoryId=categoryId;ViewBag.Search=search;return View(q.ToList());}
public IActionResult Details(int id){var p=s.FindProduct(id);return p==null?NotFound():View(p);}
}