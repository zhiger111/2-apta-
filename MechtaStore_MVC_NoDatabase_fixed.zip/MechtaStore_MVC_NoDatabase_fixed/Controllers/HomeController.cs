using Microsoft.AspNetCore.Mvc;using MechtaStore.Services;
namespace MechtaStore.Controllers;
public class HomeController:Controller {readonly StoreService s;public HomeController(StoreService x)=>s=x;public IActionResult Index(){ViewBag.Categories=s.Categories;return View(s.Products.OrderByDescending(x=>x.Id).Take(8).ToList());}public IActionResult Error()=>View();}