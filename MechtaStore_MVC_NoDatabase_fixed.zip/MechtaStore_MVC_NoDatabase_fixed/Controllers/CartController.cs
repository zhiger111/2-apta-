using Microsoft.AspNetCore.Mvc;

namespace MechtaStore.Controllers;

public class CartController : Controller
{
    public IActionResult Index() => View();
}
