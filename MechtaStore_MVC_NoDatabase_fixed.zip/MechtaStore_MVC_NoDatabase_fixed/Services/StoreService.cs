using MechtaStore.Models;
namespace MechtaStore.Services;
public class StoreService {
 public List<Category> Categories {get;} = new(){
 new(){Id=1,Name="Смартфоны",Slug="smartphones"},new(){Id=2,Name="Ноутбуки и компьютеры",Slug="laptops"},new(){Id=3,Name="Телевизоры",Slug="tvs"},new(){Id=4,Name="Бытовая техника",Slug="appliances"},new(){Id=5,Name="Наушники и аудиотехника",Slug="audio"},new(){Id=6,Name="Игровые устройства",Slug="gaming"},new(){Id=7,Name="Аксессуары",Slug="accessories"}};
 public List<Product> Products {get;} = new();
 public List<User> Users {get;} = new();
 public List<Order> Orders {get;} = new();
 int nextUser=1,nextOrder=1,nextProduct=5;
 public StoreService(){
 Products.AddRange(new[]{
 new Product{Id=1,Name="Смартфон Samsung Galaxy S24 256GB",CategoryId=1,Category=Categories[0],Price=429990,OldPrice=499990,StockQuantity=15,Description="Флагманский смартфон с AMOLED-экраном.",Specifications="Память: 256 GB\nЭкран: 6.2 AMOLED\nКамера: 50 Мп"},
 new Product{Id=2,Name="Ноутбук Lenovo IdeaPad 3 15”",CategoryId=2,Category=Categories[1],Price=289990,StockQuantity=8,Description="Ноутбук для работы и учёбы.",Specifications="Процессор: Ryzen 5\nОЗУ: 16 GB\nSSD: 512 GB"},
 new Product{Id=3,Name="Телевизор LG 55” 4K Smart TV",CategoryId=3,Category=Categories[2],Price=319990,OldPrice=359990,StockQuantity=5,Description="4K-телевизор с webOS.",Specifications="Диагональ: 55\nРазрешение: 3840x2160\nSmart TV: webOS"},
 new Product{Id=4,Name="Наушники Sony WH-1000XM5",CategoryId=5,Category=Categories[4],Price=169990,StockQuantity=0,Description="Беспроводные наушники с шумоподавлением.",Specifications="Тип: накладные\nBluetooth: 5.2\nАвтономность: 30 ч"}});
 var admin=new User{Id=nextUser++,FullName="Администратор",Email="admin@mechta.kz",PasswordHash=BCrypt.Net.BCrypt.HashPassword("AdminPass123!"),Role=UserRole.Admin};Users.Add(admin);
 }
 public User? FindUser(string email)=>Users.FirstOrDefault(x=>x.Email==email);
 public User AddUser(User u){u.Id=nextUser++;Users.Add(u);return u;}
 public Order AddOrder(Order o){o.Id=nextOrder++;Orders.Add(o);return o;}
 public Product? FindProduct(int id)=>Products.FirstOrDefault(x=>x.Id==id);
 public Product AddProduct(Product p){p.Id=nextProduct++;p.Category=Categories.FirstOrDefault(c=>c.Id==p.CategoryId)!;Products.Add(p);return p;}
}