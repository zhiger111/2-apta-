using System.ComponentModel.DataAnnotations;
namespace MechtaStore.Models;
public class RegisterVm { [Required,MaxLength(100)] public string FullName{get;set;}=""; [Required,EmailAddress] public string Email{get;set;}=""; [Required,MinLength(8)] public string Password{get;set;}=""; }
public class LoginVm { [Required,EmailAddress] public string Email{get;set;}=""; [Required] public string Password{get;set;}=""; }
public class CheckoutVm { [Required] public string CustomerName{get;set;}=""; [Required] public string Phone{get;set;}=""; [Required] public string City{get;set;}="Алматы"; [Required] public string Address{get;set;}=""; public string ItemsJson{get;set;}="[]"; }
public class CartLineVm { public int ProductId{get;set;} public int Quantity{get;set;} }
public class ProductFormVm { public int Id{get;set;} [Required] public string Name{get;set;}=""; public string Description{get;set;}=""; public string Specifications{get;set;}=""; [Range(0,999999999)] public decimal Price{get;set;} public decimal? OldPrice{get;set;} public string ImageUrl{get;set;}=""; public int StockQuantity{get;set;} public int CategoryId{get;set;} }
